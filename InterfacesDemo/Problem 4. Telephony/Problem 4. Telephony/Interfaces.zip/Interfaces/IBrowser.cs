﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem4Telephony.Interfaces
{
    public interface IBrowser
    {
        string Browse(string url);
    }
}
