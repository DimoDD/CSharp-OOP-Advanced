﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem4Telephony
{
    public interface ICaller
    {
        string Call(string number);
    }
}
